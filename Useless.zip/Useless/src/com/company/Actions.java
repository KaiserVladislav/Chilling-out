package com.company;

import java.util.ArrayList;

public class Actions {
    private static boolean game_over_E=false; // trigger to shut down the game
    private static boolean game_over_H=false; // trigger to shut down the game
    private static boolean game_over_C=false; // trigger to shut down the game
    private static int cataclysmEnding=-1;
    public static int probabilityOfCataclysm=0;
    private static int iteration=0; // basically time counter



    public static int getIteration() {
        return iteration;
    }
    public static void move_everybody() {
        for (Herbivore hb:
             Game_field.getHerbivores()) {
            hb.move();
        }
        for (Carnivore cv:
             Game_field.getCarnivores()) {
            cv.move();
        }
        iteration++; //one month mb
    }

    public static void eat_everybody(){
        ArrayList<Herbivore> herbivores = Game_field.getHerbivores();
        ArrayList<Carnivore> carnivores = Game_field.getCarnivores();

        for (Herbivore hb:
                herbivores) {
            hb.eat();
        }
        for(Carnivore cv:
                carnivores){
            cv.eat();
        }
    }

    public static void refresh(){
        ArrayList<Herbivore> herbivores = Game_field.getHerbivores();
        ArrayList<Carnivore> carnivores = Game_field.getCarnivores();
        invoke_cataclysm();

        if (herbivores.size()>=1){
            herbivores.removeIf(hb -> !hb.is_alive()); // Collections.removeIf!!!
        }
        if (carnivores.size()>=1){
            carnivores.removeIf(cv -> !cv.is_alive());
        }

        if (herbivores.size()==0 && carnivores.size()==0){
            game_over_Everybody();
        }
        if(herbivores.size()==0){
            game_over_Herbivores();
        }

        if(carnivores.size()==0){
            game_over_Carnivores();
        }
    }

    public static void game_over_Everybody(){
        game_over_E=true;
    }
    public static void game_over_Herbivores(){
        game_over_H=true;
    }
    public static void game_over_Carnivores(){
        game_over_C=true;
    }

    public static boolean isGame_over_E() {
        return game_over_E;
    }

    public static boolean isGame_over_C() {
        return game_over_C;
    }

    public static boolean isGame_over_H() {
        return game_over_H;
    }

    public static int getProbabilityOfCataclysm(){
        return probabilityOfCataclysm;
    }
    public static void setProbabilityOfCataclysm(int prob){
        probabilityOfCataclysm=prob;
    }

    public static void invoke_cataclysm(){ // prob ~one through 25  is reasonable
        int checker = Game_field.getRandom().nextInt(100);
        if(checker<=probabilityOfCataclysm){
            Cataclysm cataclysm = new Cataclysm(probabilityOfCataclysm);
        }


    }
    public static void setCataclysmEnding(int cataclysmEnding){
        Actions.cataclysmEnding=cataclysmEnding;
    }

    public static int getCataclysmEnding() {
        return cataclysmEnding;
    }

}

