package com.company;

import java.util.ArrayList;
import java.util.Random;

public class Cataclysm {
    public static final int CATACLYSM_METEORITE_STRIKE=0;
    public static final int CATACLYSM_ACID_RAIN=1;
    public static final int CATACLYSM_DEADLY_BLIZZARD=2;
    public static final int CATACLYSM_EARTHQUAKE=3;


    public Cataclysm(int prob){
        int typeOfCataclysm = Game_field.getRandom().nextInt(10);
        typeOfCataclysm=typeOfCataclysm%4;

        if(typeOfCataclysm==0)
            Meteorite_strike();
        else if(typeOfCataclysm==1)
            Acid_rains();
        else if(typeOfCataclysm==2)
            Deadly_blizzard();
        else
            Earthquake();

    }

    public static void Meteorite_strike(){
        ArrayList<Carnivore> carnivores = Game_field.getCarnivores();
        ArrayList<Herbivore> herbivores = Game_field.getHerbivores();
        // everyone dies
        for (Carnivore cv:
             carnivores) {
            cv.die();
        };
        for (Herbivore hb:
                herbivores) {
            hb.die();
        };
        Actions.setCataclysmEnding(CATACLYSM_METEORITE_STRIKE);
        //System.out.println("PHU BAM! EVERYONE IS DEAD NOW!");
    }
    public static void Acid_rains(){
        // half randomly dies
        Random random = Game_field.getRandom();
        int prob = random.nextInt(10);
        int totalAmountOfAnimals = Game_field.getC()+Game_field.getH();
        int half = totalAmountOfAnimals/2;

        while(half>=1){
            prob = random.nextInt(10);
            if(prob<5){
                //hb dies
                Game_field.selectRandomHerbivore().die();
            }else{
                // cv dies
                Game_field.selectRandomCarnivore().die();
            }
            half--;
        }
        Actions.setCataclysmEnding(CATACLYSM_ACID_RAIN);
        //System.out.println("Welp... It's been raining for a while now... Much has changed");
    }
    public static void Deadly_blizzard(){
        // all grass dies
        for (int i = 0; i < Game_field.game_field.length; i++) {
            for (int j = 0; j < Game_field.game_field[i].length; j++) {
                if(Game_field.game_field[i][j].equals("+")){
                    Game_field.game_field[i][j]="-";
                }
            }
        }
        Actions.setCataclysmEnding(CATACLYSM_DEADLY_BLIZZARD);
        //System.out.println("FTSHUUUU! All grass evaporated!");

    }
    public static void Earthquake(){
        // quarter randomly dies
        Random random = Game_field.getRandom();
        int prob = random.nextInt(10);
        int totalAmountOfAnimals = Game_field.getC()+Game_field.getH();
        int quarter = totalAmountOfAnimals/4;

        while(quarter>=1){
            prob = random.nextInt(10);
            if(prob<5){
                //hb dies
                Game_field.selectRandomHerbivore().die();
            }else{
                // cv dies
                Game_field.selectRandomCarnivore().die();
            }
            quarter--;
        }
        Actions.setCataclysmEnding(CATACLYSM_EARTHQUAKE);
        //System.out.println("What was it? Why is it so mountainous now?");
    }


}
